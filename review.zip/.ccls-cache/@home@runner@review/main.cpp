#include <iostream>
#include <string>
#include <list>
#include <vector>
#include <time.h>
#include <cstdlib>
#include <algorithm>
using namespace std;

void printTable(string table[3][3])
{
      for(int i = 0; i < 3; i++)
      {
        for( int j = 0; j < 3; j++)
          {
            cout << table[i][j] << " ";
          }
        cout << endl;
      }
}
void printBlanks(vector<string> spaces)
{
  for(int i = 0; i < spaces.size(); i++)
    {
      cout << spaces.at(i);
    }
}
bool checkIfPlaceisBlank(string userInput, vector<string> &spaces)
{
  pair<bool, int> result;
  auto it = std::find(spaces.begin(), spaces.end(), userInput);
  if (it != spaces.end()) 
    {
      result.second = distance(spaces.begin(), it);
      result.first = true;
      spaces.erase(it);
      spaces.shrink_to_fit();
    }
    else {
      result.first = false;
      result.second = -1;
    }
  
  return result.first;
}

void gameplay(string gamepad[3][3], vector<string> &spaces)
{
  bool turn = true;
  string userYesNo;
  cout << "Do you want to go first? [Y/n]";
      cin >> userYesNo;
      bool userFirst = true;
      if(userYesNo != "Y")
      {
        userFirst = false;
      }
      while(turn)
        {
                string rowVal;
      string colVal;
      string input;
      if(userFirst)
      {
        printTable(gamepad);
        cout << "Enter cordinate num for row";
        cin >> rowVal;
        cout << "Enter cordinate num for colum";
        cin >> colVal;
        input = rowVal + "," + colVal + " ";
        if(checkIfPlaceisBlank(input, spaces))
        {
          int row = stoi(rowVal);
          int col = stoi(colVal);
          gamepad[row][col] = "X";
          printTable(gamepad);
          turn = false;
        }
      }

      
        
        int computerChoice = rand() % spaces.size();
        
        string rowCol = spaces.at(computerChoice);
        if(checkIfPlaceisBlank(rowCol, spaces))
        {
         
          int row = rowCol[0] - '0';
        
          int col = rowCol[2] - '0';
          // cout << row << col;
          gamepad[row][col] = "O";
          printTable(gamepad);
          userFirst =  true;
        }

      
        }


}

void deleteValFromSpaces(vector<string> &spaces)
{
  
}


int main() 
{
  bool userConfirm = true;
  srand(time(0));
  do
    {
      string userYesNo;
      cout << "Do you want to play Tic Tac Toe? [Y/n]";
      cin >> userYesNo;
      while(userConfirm)
        {
          if(userYesNo == "Y")
          {
            userConfirm = false;
            
          }
          else if(userYesNo == "n")
          {
            cout << "Goodbye";
            return 1;
          }
          else
          {
            cout << "Please enter Y or n";
            cin >> userYesNo;
          }
        }
      
      string two_d[3][3];
      vector<string> blankSpace;
      
      //populate
      for(int i = 0; i < 3; i++)
      {
        for( int j = 0; j < 3; j++)
          {
            //cout << i << "," << j << " ";
            string input = to_string(i) + "," + to_string(j) + " ";
            two_d[i][j] = input;
            blankSpace.push_back(input);
          }
      }


      while(blankSpace.size() > 0)
        {
          gameplay(two_d, blankSpace);
        }

      
      userConfirm = true;
    }
    while(userConfirm);
  

  
}

